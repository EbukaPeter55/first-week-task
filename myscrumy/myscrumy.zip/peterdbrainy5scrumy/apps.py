from django.apps import AppConfig


class Peterdbrainy5ScrumyConfig(AppConfig):
    name = 'peterdbrainy5scrumy'
